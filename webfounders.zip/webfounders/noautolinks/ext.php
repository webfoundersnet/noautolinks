<?php
namespace webfounders\noautolinks;

class ext extends \phpbb\extension\base
{
    public function is_enableable()
    {
        return true;
    }
}