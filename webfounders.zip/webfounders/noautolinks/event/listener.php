<?php
namespace webfounders\noautolinks\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
    public static function getSubscribedEvents()
    {
        return [
            // Runs before the parser outputs the final post
            'core.modify_text_for_display_before' => 'disable_magic_url',
        ];
    }

    public function disable_magic_url($event)
    {
        // Remove auto-generated <a> tags from magic_url
        // This keeps [url] BBCode intact
        $text = $event['text'];

        // This regex removes auto-links added by make_clickable/magic_url
        // but leaves BBCode links untouched
        $text = preg_replace('#<a class="postlink" href="([^"]+)">\\1</a>#i', '$1', $text);

        $event['text'] = $text;
    }
}
